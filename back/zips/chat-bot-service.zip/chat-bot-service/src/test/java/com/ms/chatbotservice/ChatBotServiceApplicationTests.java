package com.ms.chatbotservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatBotServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
