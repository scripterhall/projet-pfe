package com.ms.corbeilleservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CorbeilleServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CorbeilleServiceApplication.class, args);
	}

}
