package com.ms.gestionProductBacklog.gestionproductbacklog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionProductBacklogApplicationTests {

	@Test
	void contextLoads() {
	}

}
