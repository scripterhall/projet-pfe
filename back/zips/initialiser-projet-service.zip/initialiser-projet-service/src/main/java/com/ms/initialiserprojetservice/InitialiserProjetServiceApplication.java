package com.ms.initialiserprojetservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InitialiserProjetServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(InitialiserProjetServiceApplication.class, args);
	}

}
