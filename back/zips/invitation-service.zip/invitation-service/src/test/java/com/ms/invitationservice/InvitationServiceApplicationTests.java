package com.ms.invitationservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InvitationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
