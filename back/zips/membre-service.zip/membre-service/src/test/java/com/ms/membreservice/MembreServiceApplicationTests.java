package com.ms.membreservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MembreServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
