package com.ms.sauvegarderdossierservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SauvegarderDossierServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
