package com.ms.sprintbacklogservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SprintBacklogServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SprintBacklogServiceApplication.class, args);
	}

}
