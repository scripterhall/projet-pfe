package com.ms.sprintbacklogservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SprintBacklogServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
