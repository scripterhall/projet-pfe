package com.ms.tickettacheservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TicketTacheServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TicketTacheServiceApplication.class, args);
	}

}
