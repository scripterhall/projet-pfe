package com.ms.tickettacheservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TicketTacheServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
